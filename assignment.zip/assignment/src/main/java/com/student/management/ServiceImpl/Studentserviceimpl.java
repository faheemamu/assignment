package com.student.management.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.student.management.Entity.Student;
import com.student.management.Repository.StudentRepository;
import com.student.management.Service.StudentService;
@Service
public class Studentserviceimpl implements StudentService {
private StudentRepository studentRepository;

	public Studentserviceimpl(StudentRepository studentRepository) {
	super();
	this.studentRepository = studentRepository;
}

	public List<Student> getallstudents() {
		
		return studentRepository.findAll();
	}

	public Student savestudent(Student student) {
		
		return studentRepository.save(student);
	}

	public Student getStudentbyId(int id) {
		
		return studentRepository.findById(id).get() ;
	}

	public Student updatestudent(Student student) {
		
		return studentRepository.save(student);
	}

	public void deleteStudents(int id) {
		studentRepository.deleteById(id);
		
	}

}
