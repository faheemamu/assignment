package com.student.management.Entity;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student_table")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
private int id;	
	@Column(name="StudentName",length = 20)
 private String name;
	@Column(name = "StudentAddress")
 private String address;
	@Column(name="StudentFather")
 private String fatherName;
	@Column(name="StudentMobileNumber",length=2388)
 private String mobilenumber ;
	public Student() {
		super();
		
	}
	public Student(int id, String name, String address, String fatherName, String mobilenumber) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.fatherName = fatherName;
		this.mobilenumber = mobilenumber;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", address=" + address + ", fatherName=" + fatherName
				+ ", mobilenumber=" + mobilenumber + "]";
	}
	

}
