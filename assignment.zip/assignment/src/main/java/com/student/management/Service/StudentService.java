package com.student.management.Service;

import com.student.management.Entity.Student;

public interface StudentService {
    
java.util.List<Student>getallstudents();
         Student savestudent(Student student); 
         Student getStudentbyId(int id);
         Student  updatestudent(Student student);
         void deleteStudents(int id);
	
}
