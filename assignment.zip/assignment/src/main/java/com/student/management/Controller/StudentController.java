package com.student.management.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.student.management.Entity.Student;
import com.student.management.Service.StudentService;

@Controller
public class StudentController {

	
	private StudentService studentService;

	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}
	
	@GetMapping("/students")
	public String getallstudents(Model model) {
		model.addAttribute("students",studentService.getallstudents());
		
		return "students" ;
	}
	 @GetMapping("/students/new")
	public String createstudents(Model model)
	{
		Student stu =new Student();
		model.addAttribute("students",stu);
		
		return "new_students";	
	}
	 
	 @PostMapping("/students")
	 public String savestudents(@ModelAttribute("students") Student student)
	 {
		 studentService.savestudent(student);
		 return"redirect:/students";
		 
	 }
	 @GetMapping("/students/edit/{id}")
	 public String getbyId(@PathVariable int id, Model model)
	 
	 {
		 model.addAttribute("students",studentService.getStudentbyId(id) );
		 System.out.println(id);
		 return "edit_students";
		 
	 }
	 
	
	 @PostMapping("/students/{id}") 
	 public String  updateStudent(@PathVariable int id, @ModelAttribute("students") Student student ,Model model )
	  
	 {
	Student st=	 studentService.getStudentbyId(id);
	  st.setName(student.getName());
	  st.setAddress(student.getAddress());
	  st.setFatherName(student.getFatherName());
	  st.setId(student.getId());
	  st.setMobilenumber(student.getMobilenumber());
	  studentService.updatestudent(st);
	  return "redirect:/students";
	  }
	 
	 @GetMapping("/delete/{id}")
	 public String deleteStudents(@PathVariable int id)
	 
	 {
		 studentService.deleteStudents(id);
		 
		 return"redirect:/students";
		 
	 }
	 
	 
	 
	 
	 
}
