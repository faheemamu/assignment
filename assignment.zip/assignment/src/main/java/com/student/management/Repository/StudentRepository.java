package com.student.management.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.student.management.Entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer>{

}
