package com.student.management;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.student.management.Entity.Student;
import com.student.management.Repository.StudentRepository;

@SpringBootApplication
public class StudentManagementSystemApplication implements CommandLineRunner{

	public static void main(String[] args) {
	
		SpringApplication.run(StudentManagementSystemApplication.class, args);
		
	
	}
@Autowired
private StudentRepository studentRepository;
	public void run(String... args) throws Exception {
	Student student = new Student();
	student.setName("faheem");
	student.setAddress("aligarh");
	student.setMobilenumber("8115905");
	student.setId(12);
	studentRepository.save(student);
		
	}

}
